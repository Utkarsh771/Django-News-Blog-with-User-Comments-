from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns=[ 	path("", views.articles, name="articles"),
	path("articles/<int:id4>/", views.article, name="article"),
	path("article/<int:id2>/", views.comment, name="comment"),
	path("accounts/profile/", views.articles, name="articles"),
]

urlpatterns  = urlpatterns + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)