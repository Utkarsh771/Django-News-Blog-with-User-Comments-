from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User


class Article(models.Model):
	title=models.CharField(max_length=100,help_text="headline required")
	body=models.TextField(help_text="content required")
	published_date = models.DateTimeField(default=timezone.now,blank=True) 
	pic = models.ImageField(upload_to='images/', blank=True, default = 'static/default1.jpg', null=True)

class Reader(models.Model):
	name = models.CharField(max_length=25, null=True, blank=True)
	comment = models.TextField()
	emailid= models.EmailField(null=False)
	article = models.ManyToManyField(Article)

