from django.shortcuts import render, redirect
from .models import Article, Reader
from .forms import Articleform, Readerform
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
# import cv2
import PIL
# import numpy as np

# img = cv2.imread('your_image.jpg')
# res = cv2.resize(img, dsize=(54, 140)


def articles(request):
	qs1=Article.objects.all() #filter(title="Bourne")
	# for ob in qs1 :
		# im1=PIL.Image.open(ob.pic)
		# print(type(ob.pic))
		# print(type(im1))
		# print(im1.size)
		# newsize = (100, 100) 
		# ob.pic = (django.db.models.fields.files.ImageFieldFile)(im1.resize(newsize))
	dict1={"l1":qs1}
	return render(request, "articles.html", dict1)

	
def article(request, id4):
	st1=Article.objects.get(pk=id4)
	readers=reader=None
	readers=Reader.objects.all()
	for r in readers:
		print(">>>>>>>>>>>>>")
		print(r)
		if(r.article==st1):
			reader=r
			break
	readers=Reader.objects.filter(article=st1)

	d1={"x": st1, "r": readers}
	return render(request, "article.html", d1)

@login_required
def comment(request, id2):
	from django.utils import timezone
	from .forms import Readerform
	from .models import Article
	from .models import Reader	
	
	
	if(request.method!="POST"):
		form2=Readerform
		st1=Article.objects.get(pk=id2)
		readers=reader=None
		readers=Reader.objects.filter(article=st1)
		dict1={"fm2":form2, "x": st1, "r": readers}
		return render(request,"comment.html", dict1)

	if(request.method=="POST"):
		form2=Readerform(request.POST)
		
		if (form2.is_valid()):
			r1=form2.save(commit=False)
			if(r1.name is None):
				r1.name="anonymous"
			art=Article.objects.get(pk=id2)
			r1.save()
			r1.article.add(art)
			return redirect("article", id2)
			#return HttpResponse(" submitted")

		else:
		#if( not(form2.is_valid()) ):
			
			qs1=Article.objects.all() #filter(title="Bourne")
			dict1={"l1":qs1}
			#return redirect("Articles")
			return HttpResponse(form2)
