from django import forms
from .models import Article, Reader


class Articleform(forms.ModelForm):
	class Meta:
		model=Article
		fields=('title','body','published_date','pic')


class Readerform(forms.ModelForm):
	class Meta:
		model=Reader
		fields=('name','emailid','comment')

	